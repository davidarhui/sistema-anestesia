#!/usr/bin/env python3
from philips_intellivue import DiscoveryListener


result = DiscoveryListener(interface="en8").receive_one(timeout=75)
print("Monitor:", result.primary_ipv6)
print("MAC:", result.mac_addresses)
print("Endpoints:", result.endpoints)
