# USS Anestesia — Philips IntelliVue Integration SDK

> **El software médico confiable comienza entendiendo el protocolo, no adivinándolo.**

Biblioteca experimental en Python para estudiar e implementar, de forma modular y verificable, la comunicación con monitores Philips IntelliVue mediante su interfaz de exportación de datos.

El proyecto nació como parte del **Registro de Anestesia IMSS**, pero el núcleo se mantiene independiente de la interfaz gráfica, el PDF y cualquier aplicación clínica concreta.

## Estado

- [x] Descubrimiento pasivo por IPv6 multicast y UDP/24005
- [x] Extracción de IPv6, MAC y endpoints anunciados
- [x] Captura reproducible del payload binario
- [ ] Asociación
- [ ] MDS Create Event
- [ ] Poll
- [ ] Decodificación de parámetros clínicos
- [ ] API pública estable
- [ ] Integración con el Registro de Anestesia IMSS

## Filosofía: Evidence-Based Programming

Toda decisión importante debe estar respaldada por al menos una de estas evidencias:

1. Documentación técnica aplicable.
2. Captura real de tráfico de red.
3. Prueba reproducible con un monitor.
4. Prueba automatizada cuando sea posible.

Si la evidencia contradice una hipótesis, se modifica la implementación; nunca se fuerza la evidencia para justificar el código.

## Principios

- Primero comprender; después implementar.
- Un módulo, una responsabilidad.
- Sin números mágicos cuando exista un nombre de dominio apropiado.
- El transporte, el protocolo, el parser y la aplicación permanecen separados.
- Cada paquete enviado o recibido debe poder conservarse para análisis.
- El código experimental no se presenta como apto para decisiones clínicas.

## Uso actual: Discovery

```bash
python3 -m philips_intellivue.discovery_cli --interface en8 --hex
```

También puede guardar la captura:

```bash
python3 -m philips_intellivue.discovery_cli \
  --interface en8 \
  --save captures/mx450_discovery.bin
```

## Pruebas

```bash
python3 -m unittest discover -s tests -v
```

## Estructura

```text
philips_intellivue/
├── discovery.py
├── discovery_cli.py
├── transport.py
├── protocol.py
├── association.py
├── poll.py
├── parser.py
├── nomenclature.py
├── values.py
├── types.py
├── exceptions.py
└── util.py
```

## Tripulación

**Captain / Project owner:** David Arvizo Huitrón  
**Chief Engineer:** OpenAI ChatGPT (“Scotty”)

## Advertencia

Proyecto de investigación y desarrollo. No está validado como dispositivo médico, no sustituye la vigilancia clínica y no debe utilizarse para tomar decisiones asistenciales.

Philips e IntelliVue son marcas de sus respectivos propietarios. Este proyecto es independiente y no está afiliado ni respaldado por Philips.
