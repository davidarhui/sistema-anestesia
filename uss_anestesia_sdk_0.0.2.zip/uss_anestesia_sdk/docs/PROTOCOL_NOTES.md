# Notas del protocolo

## Evidencia experimental — 2026-07-31

Monitor probado:

- Modelo: 866062
- Serie: DE351A4604
- IPv6: `fe80::209:fbff:fe88:bf13`
- MAC: `00:09:fb:88:bf:13`
- Software: `M.03.01 - 85`

Hallazgos:

1. El monitor transmite anuncios IPv6 multicast:
   - origen UDP/24005
   - destino `ff02::1`
   - payload observado: 472 bytes
   - intervalo aproximado: 60 segundos

2. En macOS, el listener debe unirse explícitamente a `ff02::1` mediante `IPV6_JOIN_GROUP`.

3. El anuncio contiene varios endpoints, entre ellos el puerto 24105 con `transport_protocol=1`.

4. Un intento TCP a IPv6/24105 produjo SYN repetidos sin SYN/ACK ni RST.

## Conclusión vigente

No se asignará un significado definitivo a `transport_protocol=1` hasta verificarlo contra documentación aplicable o una captura conocida. El módulo de asociación permanece cerrado a envío especulativo.


## Regresión del parser — captura fixture

La captura exacta de 472 bytes se conserva en:

```text
tests/fixtures/mx450_DE351A4604_discovery.bin
```

Se eliminó la búsqueda global por OUI `00:09:fb`, ya que interpretaba
incorrectamente la secuencia `00:09:fb:ff:ff:88` como una segunda MAC.
La MAC se acepta ahora únicamente desde estructuras explícitas `F100`.
