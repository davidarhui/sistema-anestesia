# Principios de diseño

## 1. Evidence-Based Programming

Una implementación necesita documentación, captura reproducible o prueba real.

## 2. Primero comprender; después implementar

Un endpoint anunciado no se clasifica como TCP o UDP solo por intuición.

## 3. Una responsabilidad por módulo

Los sockets no interpretan APDUs; el parser no controla la interfaz gráfica.

## 4. Fallar de manera explícita

Cuando una variante no está implementada, se lanza una excepción específica. No se inventa un valor.

## 5. Capturas conservables

Cada intercambio relevante debe poder guardarse como BIN, HEX y metadatos.

## 6. Seguridad clínica

El SDK experimental no sustituye la observación del monitor ni debe alimentar decisiones clínicas sin validación formal.
