# Arquitectura

## Separación de capas

```text
Aplicación clínica
        ↓
API de monitor
        ↓
Association / Poll
        ↓
Protocol / Parser
        ↓
Transport
        ↓
IPv6 / UDP / multicast
```

### `transport.py`

Abre, configura y cierra sockets. No interpreta paquetes Philips.

### `discovery.py`

Interpreta anuncios de descubrimiento y devuelve `DiscoveryResult`. No imprime y no decide cómo asociarse.

### `protocol.py`

Modela estructuras binarias verificadas. No abre sockets.

### `association.py`

Gestionará el estado de asociación cuando el transporte y el primer mensaje estén documentados.

### `poll.py`

Solicitará datos únicamente después de una asociación válida.

### `values.py`

Transformará datos ya decodificados en modelos clínicos con unidades explícitas.

## Regla

Las dependencias avanzan hacia abajo. El transporte no importa módulos de protocolo ni de aplicación.
