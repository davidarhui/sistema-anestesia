# Changelog

## 0.0.1 — Astillero

### Añadido

- Estructura inicial del SDK.
- Listener de Discovery IPv6 multicast.
- Parser de IPv6, MAC, cadenas y endpoints.
- CLI independiente.
- Excepciones de dominio.
- Pruebas unitarias básicas.
- Documentación de arquitectura y principios.

### No implementado deliberadamente

- Association.
- MDS Create Event.
- Poll.
- Valores clínicos.


## 0.0.2 — Caja negra

### Corregido

- Eliminado falso positivo de MAC generado por búsqueda heurística global.

### Añadido

- Fixture binario real de Discovery de 472 bytes.
- Pruebas de regresión para IPv6, MAC, endpoints e identidad del MX450.
