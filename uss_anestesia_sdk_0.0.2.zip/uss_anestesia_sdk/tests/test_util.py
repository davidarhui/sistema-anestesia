import unittest

from philips_intellivue.util import hex_dump, mac_text


class UtilTests(unittest.TestCase):
    def test_mac_text(self):
        self.assertEqual(mac_text(b"\x00\x09\xfb\x88\xbf\x13"), "00:09:fb:88:bf:13")

    def test_hex_dump(self):
        rendered = hex_dump(b"ABC\x00")
        self.assertIn("41 42 43 00", rendered)
        self.assertTrue(rendered.endswith("ABC."))


if __name__ == "__main__":
    unittest.main()
