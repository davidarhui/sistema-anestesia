from pathlib import Path
import unittest

from philips_intellivue.discovery import parse_discovery_announcement


FIXTURE = (
    Path(__file__).parent
    / "fixtures"
    / "mx450_DE351A4604_discovery.bin"
)


class MX450DiscoveryFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = FIXTURE.read_bytes()
        cls.result = parse_discovery_announcement(
            cls.payload,
            ("fe80::209:fbff:fe88:bf13", 24005, 0, 26),
            "en8",
        )

    def test_fixture_size(self):
        self.assertEqual(len(self.payload), 472)

    def test_primary_ipv6(self):
        self.assertEqual(
            self.result.primary_ipv6,
            "fe80::209:fbff:fe88:bf13",
        )

    def test_real_mac_only(self):
        self.assertEqual(
            self.result.mac_addresses,
            ("00:09:fb:88:bf:13",),
        )
        self.assertNotIn(
            "00:09:fb:ff:ff:88",
            self.result.mac_addresses,
        )

    def test_endpoint_24105_is_present_without_transport_assumption(self):
        matches = [
            endpoint
            for endpoint in self.result.endpoints
            if endpoint.port == 24105
        ]
        self.assertEqual(len(matches), 2)
        self.assertEqual(
            {(item.application_protocol, item.transport_protocol)
             for item in matches},
            {(1, 1), (5, 1)},
        )

    def test_identity_strings_are_present(self):
        for expected in (
            "Philips",
            "866062",
            "S-M8003-1402A",
            "M.03.01 - 85",
        ):
            self.assertIn(expected, self.result.strings)

    def test_serial_is_preserved_in_raw_fixture(self):
        # Serial parsing will move to a documented identity structure.
        # Until then, this guards against corrupting or truncating the packet.
        self.assertIn(b"DE351A4604", self.payload)


if __name__ == "__main__":
    unittest.main()
