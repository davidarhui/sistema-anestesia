import struct
import unittest

from philips_intellivue.discovery import (
    parse_ipv6_addresses,
    parse_protocol_support,
)
from philips_intellivue.types import Endpoint


class DiscoveryParserTests(unittest.TestCase):
    def test_protocol_support(self):
        entries = struct.pack(">HHHH", 1, 1, 24105, 0)
        value = struct.pack(">HH", 1, len(entries)) + entries
        payload = struct.pack(">HH", 0xF101, len(value)) + value

        self.assertEqual(
            parse_protocol_support(payload),
            (Endpoint(1, 1, 24105, 0),),
        )

    def test_ipv6_tag(self):
        raw = bytes.fromhex("fe800000000000000209fbfffe88bf13")
        payload = struct.pack(">HH", 0xF35E, len(raw)) + raw
        self.assertEqual(
            parse_ipv6_addresses(payload),
            ("fe80::209:fbff:fe88:bf13",),
        )


if __name__ == "__main__":
    unittest.main()
