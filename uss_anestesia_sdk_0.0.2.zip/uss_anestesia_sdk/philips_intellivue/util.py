"""Small binary and formatting helpers."""

from __future__ import annotations


def hex_dump(data: bytes, width: int = 16) -> str:
    """Return a deterministic hexadecimal and ASCII representation."""
    if width < 1:
        raise ValueError("width must be at least 1")

    lines: list[str] = []
    for offset in range(0, len(data), width):
        chunk = data[offset : offset + width]
        hex_part = " ".join(f"{byte:02x}" for byte in chunk)
        ascii_part = "".join(
            chr(byte) if 32 <= byte <= 126 else "." for byte in chunk
        )
        lines.append(f"{offset:04x}  {hex_part:<{width * 3}}  {ascii_part}")
    return "\n".join(lines)


def mac_text(raw: bytes) -> str:
    """Format six bytes as a lowercase MAC address."""
    if len(raw) != 6:
        raise ValueError("a MAC address must contain exactly 6 bytes")
    return ":".join(f"{byte:02x}" for byte in raw)
