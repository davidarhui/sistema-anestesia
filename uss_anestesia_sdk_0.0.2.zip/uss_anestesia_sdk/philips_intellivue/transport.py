"""IPv6 transport primitives.

This module deliberately contains no Philips packet parsing.
"""

from __future__ import annotations

import socket
import struct
from dataclasses import dataclass

from .exceptions import InterfaceNotFoundError


ALL_NODES_MULTICAST = "ff02::1"
DISCOVERY_PORT = 24005


@dataclass(frozen=True)
class IPv6Interface:
    name: str
    index: int

    @classmethod
    def resolve(cls, name: str) -> "IPv6Interface":
        try:
            return cls(name=name, index=socket.if_nametoindex(name))
        except OSError as exc:
            raise InterfaceNotFoundError(
                f"No existe la interfaz {name!r}: {exc}"
            ) from exc


def create_multicast_listener(
    interface: IPv6Interface,
    *,
    port: int = DISCOVERY_PORT,
    group: str = ALL_NODES_MULTICAST,
) -> socket.socket:
    """Create an IPv6 UDP socket joined to a multicast group."""
    sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        if hasattr(socket, "SO_REUSEPORT"):
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)

        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
        sock.bind(("::", port))

        membership = struct.pack(
            "=16sI",
            socket.inet_pton(socket.AF_INET6, group),
            interface.index,
        )
        sock.setsockopt(
            socket.IPPROTO_IPV6,
            socket.IPV6_JOIN_GROUP,
            membership,
        )
        return sock
    except Exception:
        sock.close()
        raise
