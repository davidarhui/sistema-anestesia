"""Protocol-layer structures.

No Association APDU is emitted yet. Structures will be added only when their
binary format and transport mapping have been verified against documentation
and/or reproducible captures.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class ProtocolState(Enum):
    IDLE = auto()
    DISCOVERED = auto()
    ASSOCIATING = auto()
    ASSOCIATED = auto()
    POLLING = auto()
    CLOSED = auto()


@dataclass(frozen=True)
class RawProtocolMessage:
    payload: bytes
    description: str = "unclassified"
