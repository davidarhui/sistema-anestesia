"""Passive IntelliVue discovery over IPv6 multicast."""

from __future__ import annotations

import socket
import struct
from datetime import datetime
from typing import Optional

from .exceptions import DiscoveryTimeoutError, ProtocolDecodeError
from .transport import DISCOVERY_PORT, IPv6Interface, create_multicast_listener
from .types import DiscoveryResult, Endpoint
from .util import mac_text


TAG_PROTOCOL_SUPPORT = 0xF101
TAG_IPV6_ADDRESS = 0xF35E
TAG_MAC_ADDRESS = 0xF100


def find_tag(data: bytes, tag: int) -> list[tuple[int, bytes]]:
    """Locate simple 16-bit tag + 16-bit length structures."""
    needle = struct.pack(">H", tag)
    results: list[tuple[int, bytes]] = []
    start = 0

    while True:
        index = data.find(needle, start)
        if index < 0:
            break

        if index + 4 <= len(data):
            length = struct.unpack_from(">H", data, index + 2)[0]
            end = index + 4 + length
            if end <= len(data):
                results.append((index, data[index + 4 : end]))

        start = index + 1

    return results


def parse_protocol_support(data: bytes) -> tuple[Endpoint, ...]:
    endpoints: list[Endpoint] = []

    for _, value in find_tag(data, TAG_PROTOCOL_SUPPORT):
        if len(value) < 4:
            continue

        count, declared_length = struct.unpack_from(">HH", value, 0)
        entries_blob = value[4:]

        if declared_length > len(entries_blob):
            raise ProtocolDecodeError(
                "La longitud declarada de F101 excede el payload disponible."
            )

        entries_blob = entries_blob[:declared_length]
        number_to_read = min(count, len(entries_blob) // 8)

        for position in range(number_to_read):
            fields = struct.unpack_from(">HHHH", entries_blob, position * 8)
            endpoints.append(Endpoint(*fields))

    return tuple(endpoints)


def parse_ipv6_addresses(data: bytes) -> tuple[str, ...]:
    addresses: list[str] = []
    for _, value in find_tag(data, TAG_IPV6_ADDRESS):
        if len(value) >= 16:
            addresses.append(socket.inet_ntop(socket.AF_INET6, value[:16]))
    return tuple(dict.fromkeys(addresses))


def parse_mac_addresses(data: bytes) -> tuple[str, ...]:
    """Extract MAC addresses only from explicit F100 structures.

    A previous heuristic scanned the whole payload for the Philips OUI
    ``00:09:fb``. That produced false positives inside unrelated fields.
    Evidence from the captured MX450 packet shows the real MAC twice in F100,
    so the parser now accepts only structurally identified values.
    """
    candidates: list[str] = []

    for _, value in find_tag(data, TAG_MAC_ADDRESS):
        if len(value) >= 6:
            candidates.append(mac_text(value[:6]))

    return tuple(dict.fromkeys(candidates))


def extract_length_prefixed_ascii(data: bytes) -> tuple[str, ...]:
    strings: list[str] = []

    for index in range(0, len(data) - 4):
        length = struct.unpack_from(">H", data, index)[0]
        if not 4 <= length <= 64:
            continue

        end = index + 2 + length
        if end > len(data):
            continue

        candidate = data[index + 2 : end].rstrip(b"\x00")
        if candidate and all(32 <= byte <= 126 for byte in candidate):
            text = candidate.decode("ascii", errors="replace")
            if text not in strings:
                strings.append(text)

    return tuple(strings)


def parse_discovery_announcement(
    data: bytes,
    sender: tuple,
    interface: str,
) -> DiscoveryResult:
    sender_ipv6, sender_port, _flowinfo, scope_id = sender

    return DiscoveryResult(
        captured_at=datetime.now().astimezone().isoformat(timespec="seconds"),
        interface=interface,
        sender_ipv6=sender_ipv6,
        sender_port=sender_port,
        scope_id=scope_id,
        payload=data,
        ipv6_addresses=parse_ipv6_addresses(data),
        mac_addresses=parse_mac_addresses(data),
        endpoints=parse_protocol_support(data),
        strings=extract_length_prefixed_ascii(data),
    )


class DiscoveryListener:
    """Receive structured discovery announcements."""

    def __init__(self, interface: str = "en8") -> None:
        self.interface = IPv6Interface.resolve(interface)

    def receive_one(self, timeout: Optional[float] = None) -> DiscoveryResult:
        sock = create_multicast_listener(self.interface)
        try:
            sock.settimeout(timeout)
            try:
                data, sender = sock.recvfrom(65535)
            except socket.timeout as exc:
                raise DiscoveryTimeoutError(
                    "No se recibió un anuncio IntelliVue antes del timeout."
                ) from exc
            return parse_discovery_announcement(
                data=data,
                sender=sender,
                interface=self.interface.name,
            )
        finally:
            sock.close()
