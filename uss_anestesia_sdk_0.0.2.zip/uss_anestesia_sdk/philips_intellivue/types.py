"""Shared immutable domain types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class Endpoint:
    """Endpoint advertised by an IntelliVue discovery packet."""

    application_protocol: int
    transport_protocol: int
    port: int
    options: int


@dataclass(frozen=True)
class DiscoveryResult:
    """Structured representation of one discovery announcement."""

    captured_at: str
    interface: str
    sender_ipv6: str
    sender_port: int
    scope_id: int
    payload: bytes
    ipv6_addresses: Tuple[str, ...]
    mac_addresses: Tuple[str, ...]
    endpoints: Tuple[Endpoint, ...]
    strings: Tuple[str, ...]

    @property
    def primary_ipv6(self) -> str:
        return self.ipv6_addresses[0] if self.ipv6_addresses else self.sender_ipv6
