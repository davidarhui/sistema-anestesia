"""Polling support placeholder.

Implementation begins after Association and MDS Create Event are reproducible.
"""
