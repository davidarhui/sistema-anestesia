"""Higher-level response parser placeholder."""
