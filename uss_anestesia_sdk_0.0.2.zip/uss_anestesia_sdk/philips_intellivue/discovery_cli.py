"""Command-line interface for passive discovery."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

from .discovery import DiscoveryListener
from .exceptions import IntelliVueError
from .util import hex_dump


def save_result(result, output: Path, overwrite: bool) -> None:
    output = output.expanduser().with_suffix(".bin")
    output.parent.mkdir(parents=True, exist_ok=True)

    json_path = output.with_suffix(".json")
    hex_path = output.with_suffix(".hex.txt")

    existing = [path for path in (output, json_path, hex_path) if path.exists()]
    if existing and not overwrite:
        names = ", ".join(str(path) for path in existing)
        raise FileExistsError(
            f"Ya existe(n): {names}. Usa --overwrite o elige otra ruta."
        )

    output.write_bytes(result.payload)
    metadata = asdict(result)
    metadata.pop("payload")
    json_path.write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    hex_path.write_text(hex_dump(result.payload) + "\n", encoding="utf-8")


def print_result(result, show_hex: bool) -> None:
    print("\n" + "=" * 76)
    print(f"[{result.captured_at}] Anuncio IntelliVue recibido")
    print(
        f"Origen:     "
        f"[{result.sender_ipv6}%{result.scope_id}]:{result.sender_port}"
    )
    print(f"Payload:    {len(result.payload)} bytes")

    if result.ipv6_addresses:
        print("IPv6 anunciada:")
        for address in result.ipv6_addresses:
            print(f"  - {address}")

    if result.mac_addresses:
        print("MAC encontrada:")
        for address in result.mac_addresses:
            print(f"  - {address}")

    if result.endpoints:
        print("Endpoints anunciados:")
        for endpoint in result.endpoints:
            print(
                "  - app={app} transporte={transport} puerto={port} "
                "opciones=0x{options:04x}".format(
                    app=endpoint.application_protocol,
                    transport=endpoint.transport_protocol,
                    port=endpoint.port,
                    options=endpoint.options,
                )
            )

    if result.strings:
        print("Cadenas identificables:")
        for text in result.strings:
            print(f"  - {text}")

    if show_hex:
        print("\nHex dump del payload:")
        print(hex_dump(result.payload))


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Escucha pasivamente anuncios Philips IntelliVue "
            "por IPv6/UDP 24005."
        )
    )
    parser.add_argument("--interface", default="en8")
    parser.add_argument("--timeout", type=float, default=75.0)
    parser.add_argument("--hex", action="store_true")
    parser.add_argument("--save", type=Path, metavar="RUTA.bin")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if args.timeout <= 0:
        parser.error("--timeout debe ser mayor que cero")

    print(
        f"Escuchando en [{args.interface}] UDP/24005.\n"
        f"Tiempo máximo: {args.timeout:g} segundos.\n"
        "Ctrl+C para cancelar."
    )

    try:
        result = DiscoveryListener(args.interface).receive_one(args.timeout)
        print_result(result, args.hex)

        if args.save:
            save_result(result, args.save, args.overwrite)
            print(f"\nCaptura guardada con base: {args.save.with_suffix('.bin')}")

        return 0
    except KeyboardInterrupt:
        print("\nOperación cancelada.")
        return 130
    except (IntelliVueError, OSError, FileExistsError) as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
