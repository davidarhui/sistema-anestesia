"""Association state machine placeholder.

Evidence gate:
- The exact transport mapping for advertised endpoints must be established.
- The first request payload must be derived from applicable documentation or
  a known-good capture.
- No speculative packet is sent from this module.
"""

from __future__ import annotations

from dataclasses import dataclass

from .exceptions import UnsupportedProtocolError
from .types import DiscoveryResult


@dataclass
class AssociationClient:
    discovery: DiscoveryResult

    def associate(self) -> None:
        raise UnsupportedProtocolError(
            "Association aún no implementada: falta verificar transporte "
            "y formato binario del primer mensaje."
        )
