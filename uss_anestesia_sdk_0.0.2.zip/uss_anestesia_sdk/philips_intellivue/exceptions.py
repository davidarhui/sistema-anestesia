"""SDK-specific exceptions."""


class IntelliVueError(Exception):
    """Base exception for the SDK."""


class InterfaceNotFoundError(IntelliVueError):
    """The requested network interface does not exist."""


class DiscoveryTimeoutError(IntelliVueError):
    """No discovery announcement arrived before the timeout."""


class ProtocolDecodeError(IntelliVueError):
    """A binary protocol structure could not be decoded safely."""


class UnsupportedProtocolError(IntelliVueError):
    """The observed protocol variant is not implemented yet."""
