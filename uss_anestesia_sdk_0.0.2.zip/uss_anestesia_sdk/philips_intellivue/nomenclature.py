"""Named protocol and physiological identifiers.

Constants will be added from verified nomenclature tables only.
"""
